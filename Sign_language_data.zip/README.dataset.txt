# sign language project > 2025-03-17 1:32pm
https://universe.roboflow.com/fuad-hasan-whork/sign-language-project-shuhx

Provided by a Roboflow user
License: CC BY 4.0

